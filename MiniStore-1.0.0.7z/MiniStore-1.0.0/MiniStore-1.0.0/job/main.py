import os
import json
import datetime
from deepdiff import DeepDiff
import oracledb  # or cx_Oracle

# ========== CONFIGURATION ==========
DB_CONFIG = {
    "user": "your_user",
    "password": "your_password",
    "dsn": "host:port/service",  # e.g. "localhost:1521/orclpdb1"
}
BACKUP_BASE_DIR = "plsql_snapshots"
# ===================================

def get_all_source():
    query = """
        SELECT OWNER, NAME, TYPE, LINE, TEXT
        FROM ALL_SOURCE
        ORDER BY OWNER, NAME, TYPE, LINE
    """

    conn = oracledb.connect(**DB_CONFIG)
    cursor = conn.cursor()
    cursor.execute(query)

    source_map = {}

    for owner, name, obj_type, line, text in cursor:
        key = f"{owner}.{name}.{obj_type}"
        if key not in source_map:
            source_map[key] = []
        source_map[key].append(text.rstrip())

    cursor.close()
    conn.close()

    return source_map


def save_sql_files(source_map, folder_path):
    for key, lines in source_map.items():
        filename = f"{key}.sql".replace(" ", "_").replace("/", "_")
        filepath = os.path.join(folder_path, filename)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))


def save_snapshot_json(snapshot, folder_path):
    file_path = os.path.join(folder_path, "snapshot.json")
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(snapshot, f, indent=2)


def load_snapshot_json(folder_path):
    file_path = os.path.join(folder_path, "snapshot.json")
    if not os.path.exists(file_path):
        return None
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)


def main():
    today = datetime.date.today()
    yesterday = today - datetime.timedelta(days=1)
    today_str = today.isoformat()
    yesterday_str = yesterday.isoformat()

    today_folder = os.path.join(BACKUP_BASE_DIR, today_str)
    yesterday_folder = os.path.join(BACKUP_BASE_DIR, yesterday_str)

    os.makedirs(today_folder, exist_ok=True)

    print(f"📦 Backing up PLSQL source for {today_str}...")

    # Step 1: Get today's snapshot
    current_snapshot = get_all_source()

    # Step 2: Save as individual .sql files and a snapshot.json
    save_sql_files(current_snapshot, today_folder)
    save_snapshot_json(current_snapshot, today_folder)

    print(f"✅ Backup complete. Saved to folder: {today_folder}")

    # Step 3: Compare with yesterday if available
    previous_snapshot = load_snapshot_json(yesterday_folder)

    if previous_snapshot is None:
        print(f"ℹ️ No snapshot found for {yesterday_str}. Skipping comparison.")
        return

    diff = DeepDiff(previous_snapshot, current_snapshot, ignore_order=True)

    if diff:
        print("⚠️ Changes detected since yesterday:")
        print(json.dumps(diff, indent=2))
    else:
        print("✅ No changes detected compared to yesterday.")


if __name__ == "__main__":
    main()
